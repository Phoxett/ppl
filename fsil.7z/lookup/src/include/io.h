#ifndef IO_H
#define IO_H

char* get_file_contents(const char* filepath);

#endif
