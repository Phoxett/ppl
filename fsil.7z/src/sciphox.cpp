#include <iostream>
#include "../include/parser.hpp"


int main(int argc, char * argv[])
{
	Lexer lexer = Lexer(argv[1]);
	std::cout << lexer.content.length() << std::endl;
	while (lexer.currentChar != '\0' && lexer.position.index < lexer.content.length() - 1)
	{
		Token token = lexer.getNextToken();
		std::cout << "(type: " + token.type + ") : (value: " + token.value +") : (line: " + std::to_string(lexer.position.line) << ")" << std::endl;

	}
	return 0;
}