#include "../include/token.hpp"


Token::~Token(){}
Token::Token(){}


Token::Token(std::string type,std::string value, unsigned int start, unsigned int end)
{
	this->type = type;
	this->value = value;
	this->start = start;
	this->end = end;
}