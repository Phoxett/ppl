#include "../include/parser.hpp"
#include <iostream>


Parser::Parser(){}
Parser::~Parser(){}


Parser::Parser(Lexer lexer)
{
	this->lexer = lexer;
	this->currentToken = lexer.getNextToken();
}


void Parser::process(std::string tokenType)
{
	if (this->currentToken.type == tokenType)
	{
		this->currentToken = this->lexer.getNextToken();
	}
	else
	{
		std::cout << "Unexpected token: " << this->currentToken.value << std::endl;
		exit(1);
	}
}


Ast Parser::parse()
{
	return this->parse_statements();
}


Ast Parser::parse_statements()
{
	Ast statements;
	statements.cstatements.push_back(this->parse_statement());
	statements.cargssize++;
	while (this->currentToken.type == "COLON")
	{
		this->process("COLON");
		statements.cstatements.push_back(this->parse_statement());
		statements.cargssize++;
	}
	return statements;
}


Ast Parser::parse_statement()
{
	if (this->currentToken.type == "ID")
	{

	}
	Ast ast;
	return ast;
}


Ast Parser::parse_id()
{
	if (
		this->currentToken.value.compare("string") ||
		this->currentToken.value.compare("char") ||
		this->currentToken.value.compare("short") ||
		this->currentToken.value.compare("int") ||
		this->currentToken.value.compare("long") ||
		this->currentToken.value.compare("float") ||
		this->currentToken.value.compare("double") ||
		this->currentToken.value.compare("json") ||
		this->currentToken.value.compare("list") ||
		this->currentToken.value.compare("set") ||
		this->currentToken.value.compare("tuple"))
	{
		return this->parse_variable_definition();
	}
	else
	{
		return this->parse_variable();
	}
}


Ast Parser::parse_variable_definition()
{
	this->process("TID");
	this->process("EQUAL");
	this->process("");
}


Ast Parser::parse_expression()
{
	Ast ast;
	return ast;
}


Ast Parser::parse_factor()
{
	Ast ast;
	return ast;
}


Ast Parser::parse_term()
{
	Ast ast;
	return ast;
}


Ast Parser::parse_function_call()
{
	Ast ast;
	return ast;
}


Ast Parser::parse_variable()
{
	Ast ast;
	return ast;
}


Ast Parser::parse_string()
{
	Ast ast;
	return ast;
}