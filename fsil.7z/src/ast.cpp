#include "../include/ast.hpp"


Ast::Ast(){}
Ast::~Ast(){}


Ast::Ast(std::string type)
{
	this->type = type;
}