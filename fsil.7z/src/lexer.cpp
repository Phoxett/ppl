#include <iostream>
#include <ctype.h>
#include "../include/lexer.hpp"
#include "../include/file.hpp"
#include "../include/tokens.hpp"


Lexer::~Lexer(){}
Lexer::Lexer(){}


Lexer::Lexer(std::string filename)
{
	File file = File(filename);
	this->content = file.getContent();
	this->position.line = 1;
	this->position.index = 0;
	this->currentChar = this->content[this->position.index];
}


void Lexer::next()
{
	if (this->currentChar != '\0' && this->position.index < this->content.length() - 1)
	{
		this->position.index++;
		this->currentChar = this->content[this->position.index];
	}
}


void Lexer::skipNewline()
{
	while (this->currentChar == 10)
	{
		this->position.line++;
		this->next();
	}
}


void Lexer::skipWhitespace()
{
	while (this->currentChar == 32)
	{
		this->next();
	}
}


Token Lexer::getNextToken()
{
	while (this->currentChar != '\0' && this->position.index < this->content.length() - 1)
	{
		if (this->currentChar == 32) this->skipWhitespace();
		if (this->currentChar == 10) this->skipNewline();
		if (this->currentChar == 34) return this->getString();
		if (isalpha(this->currentChar)) return this->getIdentifier();
		if (isdigit(this->currentChar)) return this->getNumber();
		 
		switch (this->currentChar)
		{
		case 61: this->next(); return Token(TEQUAL, "=", this->position.index - 1, this->position.index - 1); break;
		case 40: this->next(); return Token(TRPAREN, "(", this->position.index - 1, this->position.index - 1); break;
		case 41: this->next(); return Token(TLPAREN, ")", this->position.index - 1, this->position.index - 1); break;
		case 91: this->next(); return Token(TRBRACK, "[", this->position.index - 1, this->position.index - 1); break;
		case 93: this->next(); return Token(TLBRACK, "]", this->position.index - 1, this->position.index - 1); break;
		case 123: this->next(); return Token(TRBRACE, "{", this->position.index - 1, this->position.index - 1); break;
		case 125: this->next(); return Token(TLBRACE, "}", this->position.index - 1, this->position.index - 1); break;
		case 44: this->next(); return Token(TCOMMA, ",", this->position.index - 1, this->position.index - 1); break;
		case 58: this->next(); return Token(TCOLON, ":", this->position.index - 1, this->position.index - 1); break;
		}
	}
	return Token(TEOF, "\0", this->position.index, this->position.index);
}


Token Lexer::getString()
{
	std::string value;
	unsigned int start, end;
	this->next();

	start = this->position.index - 1;

	while(this->currentChar != 34)
	{
		value.push_back(this->currentChar);
		this->next();
	}
	this->next();
	end = this->position.index;
	return Token(TSTRING, value, start, end);
}


Token Lexer::getNumber()
{
	std::string value;
	unsigned int start, end;
	start = this->position.index;

    while (isdigit(this->currentChar))
    {
		value.push_back(this->currentChar);
        this->next();
		if (this->currentChar == '.')
		{
			value.push_back(this->currentChar);
			this->next();
			if (this->currentChar == 46)
			{
				std::cout << "NumberFormatError: " << std::endl;
				exit(2);
			}
			if (isdigit(this->currentChar))
			{
				while (isdigit(this->currentChar))
				{
					value.push_back(this->currentChar);
					this->next();
				}
			}
			end = this->position.index;
			return Token(TFLOAT, value, start, end); 
		}
    }
	end = this->position.index;
    return Token(TINT, value, start, end);
}


Token Lexer::getIdentifier()
{
	std::string value;
	unsigned int start, end;
	start = this->position.index;
    while (isalnum(this->currentChar))
    {
        
		value.push_back(this->currentChar);
        this->next();
    }

	end = this->position.index;
    return Token(TID, value, start, end);
}