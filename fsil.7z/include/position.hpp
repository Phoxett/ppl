#ifndef POSITION_HPP
#define POSITION_HPP

struct Position
{
	unsigned int index;
	unsigned int line;
};

#endif