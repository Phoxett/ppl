#ifndef AST_HPP
#define AST_HPP

#include <string>
#include <list>

class Ast
{
	public:

		// VARIABLE

		std::string vname;

		// VARIABLE DEFINITIOn
		// type, name, size

		std::string vdtype;
		std::string vdname;
		std::string vdvalue;

		// FUNCTION CALL
		// type, name, args, size

		std::string fcname;
		std::list<Ast> fcargs;
		std::string fcargssize = 0;

		// COMPOUND
		// value, size
		
		std::list<Ast> cstatements;
		size_t cargssize  = 0;


		Ast(std::string type);

		Ast();
		~Ast();
 };
 
#endif