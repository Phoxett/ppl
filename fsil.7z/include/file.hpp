#ifndef FILE_HPP
#define FILE_HPP

#include <string>

class File
{
	public:

		std::string content;

		std::string getContent();
		
		File(std::string filename);

		File();
		~File();
};

#endif