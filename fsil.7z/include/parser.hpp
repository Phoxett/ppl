#ifndef PARSER_HPP
#define PARSER_HPP

#include "lexer.hpp"
#include "ast.hpp"

class Parser
{
	public:

		Lexer lexer;
		Token currentToken;

		
		void process(std::string tokenType);
		Ast parse();
		Ast parse_statements();
		Ast parse_statement();
		Ast parse_expression();
		Ast parse_factor();
		Ast parse_term();
		Ast parse_function_call();
		Ast parse_variable();
		Ast parse_variable_definition();
		Ast parse_string();
		Ast parse_id();


		Parser(Lexer lexer);

		Parser();
		~Parser();
};

#endif