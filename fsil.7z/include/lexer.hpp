#ifndef LEXER_HPP
#define LEXER_HPP

#include <string>
#include "position.hpp"
#include "token.hpp"

class Lexer
{
	public:

		std::string content;
		char currentChar;
		Position position;
		Token currentToken;
		Token previousToken;

		void next();
		void skipWhitespace();
		void skipNewline();

		Token getNextToken();

		Token getIdentifier();
		Token getChar(std::string charType);
		Token getString();
		Token getNumber();
		Token getDict();
		Token getSet();
		Token getList();

		Lexer(std::string filename);

		Lexer();
		~Lexer();
};

#endif