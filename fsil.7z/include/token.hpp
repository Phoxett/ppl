#ifndef TOKEN_HPP
#define TOKEN_HPP

#include <string>

class Token
{
	public:

		unsigned char type;
		std::string value;
		unsigned int start;
		unsigned int end;

		Token(unsigned char type, std::string value, unsigned int start, unsigned int end);

		Token();
		~Token();
};

#endif