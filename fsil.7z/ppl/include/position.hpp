#ifndef POSITION_HPP
#define POSITION_HPP


struct Position
{
	int index;
	int line;
	short column;
};


#endif