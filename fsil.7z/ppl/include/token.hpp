#ifndef TOKEN_HPP
#define TOKEN_HPP


#include <string>


class Token
{

	public:

	char type;
	std::string value;


	Token();
	~Token();
	

	Token(char type, std::string value);
};


#endif