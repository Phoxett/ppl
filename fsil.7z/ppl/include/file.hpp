#ifndef FILE_HPP
#define FILE_HPP

#include <string>

class File
{
	public:

	std::string content;

	std::string read();
	
	
	File();
	~File();


	File(std::string filename);
};

#endif