#ifndef LEXER_HPP
#define LEXER_HPP


#include "position.hpp"
#include "token.hpp"


class Lexer
{

	public:

	char currentchar;
	std::string content;
	Position position;
	Token previousToken;
	Token currentToken;


	void skip_Whitespace_newline();
	void next_char();
	void consume_token(std::string type);
	
	Token get_next_token();
	Token get_id();
	Token get_string();
	Token get_number();

	
	Lexer();
	~Lexer();


	Lexer(std::string filename);
};


#endif