#ifndef PARSER_HPP
#define PARSER_HPP


#include "lexer.hpp"


class Parser
{

	public:

	Lexer lexer;
	Token currentToken;


	void process(char tokenType);

	//std::string factor();
	std::string term();
	//float expression();

	Parser();
	~Parser();


	Parser(Lexer lexer);
};


#endif