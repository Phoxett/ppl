#include <fstream>
#include <sstream>
#include <streambuf>
#include "../include/file.hpp"


File::File(){}
File::~File(){}


File::File(std::string filename)
{
	std::ifstream file;
    file.open(filename);

    std::stringstream content;
    content << file.rdbuf();
	file.close();
    this->content = content.str();
}


std::string File::read()
{
	return this->content;
}