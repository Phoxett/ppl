#include "../include/parser.hpp"
#include "../include/tokens.hpp"

Parser::Parser(){}
Parser::~Parser(){}


// initialisation

Parser::Parser(Lexer lexer)
{
	this->lexer = lexer;
	this->currentToken = this->lexer.get_next_token();
}


// process 

void Parser::process(char tokenType)
{
	if (this->currentToken.type == tokenType)
	{
		this->currentToken = this->lexer.get_next_token();
	}
	else
	{
		printf("Line: %d\nUnkownError: token '%s'", this->lexer.position.line, this->currentToken.value.c_str());
		exit(2);
	}
}


// factor
/*
std::string Parser::factor()
{
	std::string result;
	Token token = this->currentToken;
	if (token.type == TFLOAT)
	{
		this->process(TFLOAT);
		return token.value;
	}
	else if (token.type == TINT)
	{
		this->process(TINT);
		return token.value;
	}
	else if (token.type == TRPAREN)
	{
		this->process(TRPAREN);
		result = this->expression();
		this->process(TLPAREN);
		return result;
	}
}*/


// term

