#include <ctype.h>
#include <cstdio>
#include "../include/lexer.hpp"
#include "../include/file.hpp"
#include "../include/tokens.hpp"


Lexer::Lexer(){}
Lexer::~Lexer(){}


// initialise lexer

Lexer::Lexer(std::string filename)
{
	File file = File(filename);

	this->content = file.read();
	this->position = {0, 1, 1};
	this->currentchar = this->content[this->position.index];
}


// skip whitespace & newlines

void Lexer::skip_Whitespace_newline()
{
	while ((this->currentchar != '\0') && (this->currentchar == ' ') || (this->currentchar == '\n'))
	{
		if (this->currentchar == ' ')
		{
			this->next_char();
			this->position.column++;
		}
		else
		{
			this->next_char();
			this->position.column = 0;
			this->position.line++;
		}
	}
}


// move position to nect character

void Lexer::next_char()
{
	if (this->currentchar != '\0' && this->position.index < this->content.length() - 1)
	{
		this->position.index++;
		this->currentchar = this->content[this->position.index];
	}
}


// get the next token

Token Lexer::get_next_token()
{
	while (this->currentchar != '\0' && this->position.index < this->content.length() - 1)
	{
		if (this->currentchar == ' ' || this->currentchar == '\n')
		{
			this->skip_Whitespace_newline();
		}
		if (this->currentchar == '\"')
		{
			this->next_char();
			return this->get_string();
		}
		if (isdigit(this->currentchar))
		{
			return this->get_number();
		}
		switch (this->currentchar)
		{
		case '+':
			this->next_char();
			return Token(TPLUS, "+");
			break;
		case '-':
			this->next_char();
			return Token(TMINUS, "-");
			break;
		case '*':
			this->next_char();
			return Token(TMUL, "*");
			break;
		case '/':
			this->next_char();
			return Token(TDIV, "/");
			break;
		case '%':
			this->next_char();
			return Token(TMOD, "%");
			break;
		case '(':
			this->next_char();
			return Token(TRPAREN, "(");
			break;
		case ')':
			this->next_char();
			return Token(TLPAREN, ")");
			break;
		}
	}
}


// process number

Token Lexer::get_number()
{
	std::string value;
	int start;
	int end;
	start = this->position.index;

	while(isdigit(this->currentchar))
	{
		value.push_back(this->currentchar);
		this->next_char();

		if (this->currentchar == '.')
		{
			value.push_back(this->currentchar);
			this->next_char();

			if (this->currentchar == '.')
			{
				printf("Line %d\nNumberFormatError: unexcepted character %c\n",this->position.line, this->currentchar);
				exit(2);
			}

			if (isdigit(this->currentchar))
			{
				while (isdigit(this->currentchar))
				{
					value.push_back(this->currentchar);
					this->next_char();
				}
			}

			end = this->position.index;
			return Token(TFLOAT, value);
		}
	}

	end = this->position.index;
	return Token(TINT, value);
}


// get string

Token Lexer::get_string()
{
	std::string value;
	int start;
	int end;
	start = this->position.index;

	while (this->currentchar != '\"')
	{
		value.push_back(this->currentchar);
		this->next_char();
	}

	this->next_char();
	end = this->position.index;
	return Token(TSTRING, value);
}


// get identifier

Token Lexer::get_id()
{
	std::string value;
	int start;
	int end;
	start = this->position.index;
	while (isalnum(this->currentchar))
    {
		value.push_back(this->currentchar);
        this->next_char();
    }

	end = this->position.index;
	if (value == "int" || value == "float" || value == "string")
	{
		return Token(TID_TYPE_NAME, value);
	}
    return Token(TID, value);
}