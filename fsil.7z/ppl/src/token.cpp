#include "../include/token.hpp"


Token::Token(){}
Token::~Token(){}


Token::Token(char type, std::string value)
{
	this->type = type;
	this->value = value;
}