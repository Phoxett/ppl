#include <cstdlib>
#include <iostream>
#include <limits>


void waitForEnter();


int main()
{
    system("color 3E");
    std::cout << "hi\n";
    waitForEnter();

    std::cout << "hi again\n";
    system("color 3D");

    waitForEnter();
    return 0;
}


void waitForEnter()
{
    std::cout << "\nPress ENTER to continue...\n";
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
}